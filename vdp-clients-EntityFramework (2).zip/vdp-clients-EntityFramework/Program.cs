﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EntityFrameworkSample;
using System.Data;

namespace EntityFrameworkSample
{
   public class Program
    {
   
        public static void Main(string[] args)
        {
            try
            {
                
               SampleContext sampleContext = new SampleContext();

                //  var status = sampleContext.Database.Exists();

                //sampleContext.Database.Connection.Open();
                //var v = sampleContext.Database.Connection.State;
                //if (sampleContext.Database.Connection.State == ConnectionState.Open)
                //{
                //    sampleContext.Database.Connection.Close();
                //    Console.WriteLine("Connection Successfull");
                //}
                //else
                //{
                //    Console.WriteLine("Connection Failed");
                //}

                sampleContext.loanhub_loan_src_partys.ToList();
                var loanhub_loan_src_partys = from a in sampleContext.loanhub_loan_src_partys select a;
                foreach(var loanhub_loan_src_party in loanhub_loan_src_partys)
                {
                    Console.WriteLine(loanhub_loan_src_party.party_id + "\t" + loanhub_loan_src_party.sys_code);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Connection Failed,Please check your connection String");
            }
        }
    }
}
