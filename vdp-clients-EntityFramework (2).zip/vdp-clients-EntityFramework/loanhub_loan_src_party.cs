﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkSample
{
   public class loanhub_loan_src_party
    {
        public int party_id { get; set; }

        public string sys_code { get; set; }
    }
    
}
