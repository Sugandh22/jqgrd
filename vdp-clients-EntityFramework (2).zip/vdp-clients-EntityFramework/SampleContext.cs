﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using System.Data;



namespace EntityFrameworkSample
{    
    class SampleContext : DbContext
    {
        public DbSet<loanhub_loan_src_party> loanhub_loan_src_partys { get; set; }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //modelBuilder.Entity<loanhub_loan_src_party>()
            //    .HasKey(pk => pk.EmployeeID)
            //    .ToTable("Employees");

            modelBuilder.Entity<loanhub_loan_src_party>()
                .HasKey(pk => pk.party_id)
                .ToTable("Employees");

            //modelBuilder.Entity<loanhub_loan_src_party>()
            //    .HasRequired(p => p.EmployeeContactDetail)
            //    .WithRequiredPrincipal(c => c.loanhub_loan_src_party);
        }

    }
}
