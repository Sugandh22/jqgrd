﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dndo
{
  public  class Program
    {
      public static void Main(string[] args)
        {
            try
            {
                //using (var context = new SampleContext())
                //{
                //    var internetIncs = from a in context.InternetIncs
                //                       select a;
                //    foreach (var internetInc in internetIncs)
                //    {
                //        Console.WriteLine(internetInc.IInc_Id + "\t" + internetInc.Summary
                //            + "\t" + internetInc.TaxId + "\t" + internetInc.TTime + "\t"
                //            + internetInc.Specific_Field1 + "\t" + internetInc.Specific_Field2);
                //    }
                //}
                SampleContext sampleContext = new SampleContext();
                var status = sampleContext.Database.Exists();
                if (status == true)
                    Console.WriteLine("Connection Successfull, Database exists");
                else
                    Console.WriteLine("Connection Successfull, Database doesn't exists");

            }
            catch (Exception ex)
            {
                Console.WriteLine("Connection Failed");
            }
        }
    }
}
