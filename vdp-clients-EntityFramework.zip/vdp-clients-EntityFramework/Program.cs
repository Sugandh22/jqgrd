﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EntityFrameworkSample;
using System.Data;

namespace EntityFrameworkSample
{
   public class Program
    {
        // public  static void Main(string[] args)
        public static void Main()
        {
            try
            {
                //using (var context = new SampleContext())
                //{
                //    var internetIncs = from a in context.InternetIncs
                //                       select a;
                //    foreach (var internetInc in internetIncs)
                //    {
                //        Console.WriteLine(internetInc.IInc_Id + "\t" + internetInc.Summary
                //            + "\t" + internetInc.TaxId + "\t" + internetInc.TTime + "\t"
                //            + internetInc.Specific_Field1 + "\t" + internetInc.Specific_Field2);
                //    }
                //}
               SampleContext sampleContext = new SampleContext();

                var status = sampleContext.Database.Exists();
                // sampleContext.Database.Connection.Open();
                var v = sampleContext.Database.Connection.State;
                if (sampleContext.Database.Connection.State == ConnectionState.Open)
                {

                }
                    sampleContext.Database.Connection.Close();
                //if (status == true)
                //    Console.WriteLine("Connection Successfull, Database exists");
                //else
                //    Console.WriteLine("Connection Successfull, Database doesn't exists");

            }
            catch (Exception ex)
            {
                Console.WriteLine("Connection Failed");
            }
        }
    }
}
